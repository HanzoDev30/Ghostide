package com.rk.editor

import android.content.Context
import android.graphics.Typeface
import android.text.InputType
import android.util.AttributeSet
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.surfaceColorAtElevation
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import com.rk.DefaultScope
import com.rk.events.EditorEvent
import com.rk.events.Events
import com.rk.settings.Settings
import com.rk.settings.editor.DEFAULT_EDITOR_FONT_PATH
import com.rk.settings.editor.LineEnding
import com.rk.tabs.base.Tab
import com.rk.theme.GitColorScheme
import com.rk.utils.errorDialog
import io.github.rosemoe.sora.graphics.inlayHint.ColorInlayHintRenderer
import io.github.rosemoe.sora.graphics.inlayHint.TextInlayHintRenderer
import io.github.rosemoe.sora.lang.EmptyLanguage
import io.github.rosemoe.sora.langs.textmate.TextMateLanguage
import io.github.rosemoe.sora.lsp.editor.LspLanguage
import io.github.rosemoe.sora.text.CharPosition
import io.github.rosemoe.sora.text.TextRange
import io.github.rosemoe.sora.widget.CodeEditor
import io.github.rosemoe.sora.widget.component.EditorAutoCompletion
import io.github.rosemoe.sora.widget.component.EditorTextActionWindow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.ec4j.core.ResourceProperties
import org.ec4j.core.model.PropertyType

@Suppress("NOTHING_TO_INLINE")
class Editor : CodeEditor {
    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr)

    private val scope = CoroutineScope(Dispatchers.Default)

    var lineEnding = LineEnding.LF
    var insertFinalNewline = false
    var trimTrailingWhitespace = false
    var ownerTab: Tab? = null

    data class PatchArgs(
        val isDarkMode: Boolean,
        val editorSurface: Int,
        val surfaceContainer: Int,
        val highSurfaceContainer: Int,
        val highestSurfaceContainer: Int,
        val onSurface: Int,
        val colorPrimary: Int,
        val selectionBg: Int,
        val handleColor: Int,
        val gutterColor: Int,
        val currentLine: Int,
        val dividerColor: Int,
        val errorColor: Int,
        val gitAdded: Int,
        val gitModified: Int,
        val gitDeleted: Int,
        val gitConflicted: Int,
    )

    private var defaultColorProvider: DefaultColorProvider? = null

    private var xedTextActionWindow: XedTextActionWindow? = null

    init {
        applyFont()
        applySettings()
        getComponent(EditorAutoCompletion::class.java).setEnabledAnimation(true)
        scope.launch(Dispatchers.Main) { Events.publish(EditorEvent.InstanceCreated(this@Editor)) }

        registerInlayHintRenderers(
            TextInlayHintRenderer.DefaultInstance,
            ColorInlayHintRenderer.DefaultInstance,
        )
        defaultColorProvider = DefaultColorProvider(this)

        XedTextActionWindow(this).also { window ->
            xedTextActionWindow = window
            replaceComponent(EditorTextActionWindow::class.java, window)
        }
    }

    fun setThemeColors(
        isDarkMode: Boolean,
        selectionColors: TextSelectionColors,
        colorScheme: ColorScheme,
        gitColorScheme: GitColorScheme,
    ) {
        val surfaceColor = if (isDarkMode) colorScheme.surfaceDim else colorScheme.surface
        val surfaceContainer = colorScheme.surfaceContainer
        val highSurfaceContainer = colorScheme.surfaceContainerHigh
        val highestSurfaceContainer = colorScheme.surfaceContainerHighest
        val onSurfaceColor = colorScheme.onSurface
        val colorPrimary = colorScheme.primary
        val divider = colorScheme.outlineVariant
        val errorColor = colorScheme.error

        val selectionBackground = selectionColors.backgroundColor
        val handleColor = selectionColors.handleColor

        val gutterColor = colorScheme.surfaceColorAtElevation(1.dp)
        val currentLineColor = colorScheme.surfaceColorAtElevation(1.dp).copy(alpha = 0.8f)

        setThemeColors(
            isDarkMode = isDarkMode,
            editorSurface = surfaceColor.toArgb(),
            surfaceContainer = surfaceContainer.toArgb(),
            highSurfaceContainer = highSurfaceContainer.toArgb(),
            highestSurfaceContainer = highestSurfaceContainer.toArgb(),
            onSurface = onSurfaceColor.toArgb(),
            colorPrimary = colorPrimary.toArgb(),
            selectionBg = selectionBackground.toArgb(),
            handleColor = handleColor.toArgb(),
            gutterColor = gutterColor.toArgb(),
            currentLine = currentLineColor.toArgb(),
            dividerColor = divider.toArgb(),
            errorColor = errorColor.toArgb(),
            gitAdded = gitColorScheme.added.toArgb(),
            gitModified = gitColorScheme.modified.toArgb(),
            gitDeleted = gitColorScheme.deleted.toArgb(),
            gitConflicted = gitColorScheme.conflicted.toArgb(),
        )
    }

    fun setThemeColors(
        isDarkMode: Boolean,
        editorSurface: Int,
        surfaceContainer: Int,
        highSurfaceContainer: Int,
        highestSurfaceContainer: Int,
        onSurface: Int,
        colorPrimary: Int,
        selectionBg: Int,
        handleColor: Int,
        gutterColor: Int,
        currentLine: Int,
        dividerColor: Int,
        errorColor: Int,
        gitAdded: Int,
        gitModified: Int,
        gitDeleted: Int,
        gitConflicted: Int,
    ) {
        val patchArgs =
            PatchArgs(
                isDarkMode,
                editorSurface,
                surfaceContainer,
                highSurfaceContainer,
                highestSurfaceContainer,
                onSurface,
                colorPrimary,
                selectionBg,
                handleColor,
                gutterColor,
                currentLine,
                dividerColor,
                errorColor,
                gitAdded,
                gitModified,
                gitDeleted,
                gitConflicted,
            )

        XedColorScheme.applyPatchesTo(colorScheme, patchArgs) // pre-apply patches
        scope.launch {
            // TextMate color scheme with patches
            val createdColorScheme = ThemeManager.createColorScheme(context, patchArgs)
            withContext(Dispatchers.Main) { colorScheme = createdColorScheme }
        }
    }

    override fun release() {
        defaultColorProvider?.dispose()

        scope.cancel()
        super.release()

        DefaultScope.launch {
            Events.publish(EditorEvent.InstanceDestroyed(this@Editor))
        }
    }

    fun applySettings() {
        val tabSize = Settings.tab_size
        val pinLineNumber = Settings.pin_line_number
        val stickyScroll = Settings.sticky_scroll
        val fastDelete = Settings.quick_deletion
        val showLineNumber = Settings.show_line_numbers
        val cursorAnimation = Settings.cursor_animation
        val textSize = Settings.editor_text_size
        val wordWrap = Settings.word_wrap
        val keyboardSuggestion = Settings.show_suggestions
        val lineSpacing = Settings.line_spacing
        val renderWhitespace = Settings.render_whitespace
        val hideSoftKbd = Settings.hide_soft_keyboard_if_hardware
        val lineEndingSetting = Settings.line_ending
        val finalNewline = Settings.insert_final_newline
        val trailingWhitespace = Settings.trim_trailing_whitespace
        val completeOnEnter = Settings.complete_on_enter
        val autoClosingBracket = Settings.auto_closing_bracket
        val showMinimap = Settings.show_minimap

        props.deleteMultiSpaces = tabSize
        tabWidth = tabSize
        props.deleteEmptyLineFast = fastDelete
        props.stickyScroll = stickyScroll
        props.useICULibToSelectWords = true
        props.selectCompletionItemOnEnterForSoftKbd = completeOnEnter
        props.symbolPairAutoCompletion = autoClosingBracket
        props.showMinimap = showMinimap
        setPinLineNumber(pinLineNumber)
        isLineNumberEnabled = showLineNumber
        isCursorAnimationEnabled = cursorAnimation
        setTextSize(textSize.toFloat())
        setWordwrap(wordWrap, true, true)
        lineSpacingMultiplier = lineSpacing
        isDisableSoftKbdIfHardKbdAvailable = hideSoftKbd
        showSuggestions(keyboardSuggestion)

        LineEnding.fromValue(lineEndingSetting)?.let { lineEnding = it }
        lineSeparator = lineEnding.type
        insertFinalNewline = finalNewline
        trimTrailingWhitespace = trailingWhitespace

        props.indicatorWaveLength = 8f
        props.indicatorWaveWidth = 1.5f
        props.indicatorWaveAmplitude = 2f

        val minScaleSize: Float = 6f * resources.displayMetrics.scaledDensity
        val maxScaleSize: Float = 100f * resources.displayMetrics.scaledDensity
        setScaleTextSizes(minScaleSize, maxScaleSize)

        nonPrintablePaintingFlags =
            if (renderWhitespace) {
                FLAG_DRAW_LINE_SEPARATOR or
                    FLAG_DRAW_WHITESPACE_LEADING or
                    FLAG_DRAW_WHITESPACE_INNER or
                    FLAG_DRAW_WHITESPACE_TRAILING or
                    FLAG_DRAW_WHITESPACE_FOR_EMPTY_LINE or
                    FLAG_DRAW_WHITESPACE_IN_SELECTION
            } else 0

        lineNumberMarginLeft = 9f
        searcher.isEnsureOccurrenceVisible = true
    }

    fun applySettings(resourceProperties: ResourceProperties) {
        val indentStyle: PropertyType.IndentStyleValue? =
            resourceProperties.getValue(PropertyType.indent_style, null, false)
        val indentSize: Int? = resourceProperties.getValue(PropertyType.indent_size, null, false)
        val tabSize: Int? = resourceProperties.getValue(PropertyType.tab_width, null, false)

        indentStyle?.let {
            val useTabs = it == PropertyType.IndentStyleValue.tab
            getTextMateLanguage()?.useTab(useTabs)
        }

        val actualTabSize = indentSize ?: tabSize
        actualTabSize?.let {
            props.deleteMultiSpaces = it
            tabWidth = it
            getTextMateLanguage()?.tabSize = it
        }

        val endOfLine: PropertyType.EndOfLineValue? = resourceProperties.getValue(PropertyType.end_of_line, null, false)
        lineEnding =
            when (endOfLine) {
                PropertyType.EndOfLineValue.cr -> LineEnding.CR
                PropertyType.EndOfLineValue.lf -> LineEnding.LF
                PropertyType.EndOfLineValue.crlf -> LineEnding.CRLF
                else -> lineEnding
            }
        lineSeparator = lineEnding.type

        insertFinalNewline = resourceProperties.getValue(PropertyType.insert_final_newline, insertFinalNewline, false)
        trimTrailingWhitespace =
            resourceProperties.getValue(PropertyType.trim_trailing_whitespace, trimTrailingWhitespace, false)
    }

    /** Gets the current [TextMateLanguage], unwrapping it from [LspLanguage] if necessary. */
    fun getTextMateLanguage(): TextMateLanguage? {
        val language = editorLanguage

        if (language is TextMateLanguage) {
            return language
        }

        if (language is LspLanguage) {
            return language.wrapperLanguage as? TextMateLanguage
        }

        return null
    }

    fun applyFont() {
        runCatching {
            val fontPath = Settings.editor_font_path
            val font =
                if (fontPath.isNotEmpty()) {
                    FontCache.getTypeface(context, fontPath, Settings.is_editor_font_asset)
                        ?: FontCache.getTypeface(context, DEFAULT_EDITOR_FONT_PATH, true)
                } else {
                    FontCache.getTypeface(context, DEFAULT_EDITOR_FONT_PATH, true)
                }

            typefaceText = font ?: Typeface.DEFAULT
            typefaceLineNumber = font ?: Typeface.DEFAULT
        }
            .onFailure { errorDialog(throwable = it) }
    }

    fun showSuggestions(yes: Boolean) {
        inputType =
            if (yes) {
                InputType.TYPE_TEXT_VARIATION_NORMAL
            } else {
                InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            }
    }

    suspend fun configureLanguage(textmateScope: String) {
        val language = LanguageManager.createLanguage(textmateScope)
        language.useTab(Settings.actual_tabs)
        language.tabSize = Settings.tab_size

        if (Settings.textmate_suggestions) {
            val keywords = KeywordManager.getKeywords(textmateScope)
            keywords?.let { language.setCompleterKeywords(it.toTypedArray()) }
        }

        withContext(Dispatchers.Main) { setEditorLanguage(language) }
    }

    /**
     * Register an action button in the text action window.
     *
     * @param item The text action item instance to register.
     */
    fun registerTextAction(item: TextActionItem) {
        xedTextActionWindow?.registerTextAction(item)
    }

    /**
     * Unregister an action button in the text action window.
     *
     * @param item The text action item instance to unregister.
     */
    fun unregisterTextAction(item: TextActionItem) {
        xedTextActionWindow?.unregisterTextAction(item)
    }

    /**
     * Retrieves the currently selected text in the editor.
     *
     * @return The selected text or `null` if no text is currently selected.
     */
    fun getSelectedText(): String? {
        if (!isTextSelected) return null

        val selectionStart = cursorRange.startIndex
        val selectionEnd = cursorRange.endIndex
        return text.substring(selectionStart, selectionEnd)
    }

    companion object {
        private val uriRegex =
            Regex(
                "([a-z0-9+.-]+):(?:\\/\\/(?:((?:[a-z0-9-._~!\$&'()*+,;=:]|%[0-9A-F]{2})*)@)?((?:[a-z0-9-._~!\$&'()*+,;=]|%[0-9A-F]{2})*)(?::(\\d*))?(\\/(?:[a-z0-9-._~!\$&'()*+,;=:@/]|%[0-9A-F]{2})*)?|(\\/?(?:[a-z0-9-._~!\$&'()*+,;=:@]|%[0-9A-F]{2})+(?:[a-z0-9-._~!\$&'()*+,;=:@/]|%[0-9A-F]{2})*)?)(?:\\?((?:[a-z0-9-._~!\$&'()*+,;=:/?@]|%[0-9A-F]{2})*))?(?:#((?:[a-z0-9-._~!\$&'()*+,;=:/?@]|%[0-9A-F]{2})*))?"
            )
        private val urlRegex =
            Regex(
                "(?i)https?:\\/\\/(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{1,256}\\.[a-zA-Z0-9()]{1,6}\\b([-a-zA-Z0-9@:%_\\+.~#?&/=]*)"
            )
    }

    /**
     * Overrides the default word range detection to prioritize identifying URIs at the given position before falling
     * back to standard word boundaries.
     */
    override fun getWordRange(line: Int, column: Int, useIcu: Boolean): TextRange? {
        val urls = uriRegex.findAll(text.getLine(line))
        val foundUrl = urls.find { column in it.range.first..it.range.last }
        if (foundUrl != null) {
            return TextRange(CharPosition(line, foundUrl.range.first), CharPosition(line, foundUrl.range.last + 1))
        }

        return super.getWordRange(line, column, useIcu)
    }

    /**
     * Returns whether a URL is selected in the editor.
     *
     * @return True if a valid URL is selected, false otherwise.
     */
    fun isUrlSelected(): Boolean {
        val text = getSelectedText() ?: return false
        return urlRegex.matches(text)
    }

    fun hasFormatter(): Boolean {
        val formatter = formatterProvider?.getFormatter(this) ?: editorLanguage.getFormatter()
        return formatter != EmptyLanguage.EmptyFormatter.INSTANCE
    }
}
