package com.rk.utils

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.PictureDrawable
import android.os.Build
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.util.Log
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.core.net.toUri
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.blankj.utilcode.util.ThreadUtils
import com.caverock.androidsvg.SVG
import com.rk.App.Companion.themeManager
import com.rk.DefaultScope
import com.rk.activities.main.ui.snackbarHostStateRef
import com.rk.extension.ActivityProvider
import com.rk.file.BuiltinFileType
import com.rk.file.FileDecorationRegistry
import com.rk.file.FileObject
import com.rk.filetree.FileTreeViewModel
import com.rk.resources.getQuantityString
import com.rk.resources.getString
import com.rk.resources.plurals
import com.rk.resources.strings
import io.github.rosemoe.sora.widget.schemes.EditorColorScheme
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(DelicateCoroutinesApi::class)
inline fun runOnUiThread(runnable: Runnable) {
    GlobalScope.launch(Dispatchers.Main) { runnable.run() }
}

fun interface SnackbarController {
    fun dismiss()
}

fun showSnackbar(
    message: String,
    actionLabel: String? = null,
    withDismissAction: Boolean = false,
    duration: SnackbarDuration = if (actionLabel == null) SnackbarDuration.Short else SnackbarDuration.Indefinite,
    onAction: () -> Unit = {},
    onDismiss: () -> Unit = {},
): SnackbarController? {
    val snackbarHost = snackbarHostStateRef.get()

    if (snackbarHost == null) {
        toast(message)
        return null
    }

    val job =
        DefaultScope.launch(Dispatchers.Main) {
            val result =
                snackbarHost.showSnackbar(
                    message = message,
                    actionLabel = actionLabel,
                    withDismissAction = withDismissAction,
                    duration = duration,
                )
            when (result) {
                SnackbarResult.Dismissed -> onDismiss()
                SnackbarResult.ActionPerformed -> onAction()
            }
        }

    return { job.cancel() }
}

inline fun toast(@StringRes resId: Int) {
    toast(resId.getString())
}

suspend fun FileObject.writeObject(obj: Any) =
    withContext(Dispatchers.IO) { ObjectOutputStream(getOutputStream(false)).use { oos -> oos.writeObject(obj) } }

suspend fun FileObject.readObject(): Any? =
    withContext(Dispatchers.IO) {
        ObjectInputStream(getInputStream()).use { ois ->
            return@withContext ois.readObject()
        }
    }

fun toast(message: String?) {
    if (message.isNullOrBlank()) {
        Log.w("UTILS", "Toast with null or empty message")
        return
    }
    if (message == "Job was cancelled") {
        Log.w("TOAST", message)
        return
    }

    runOnUiThread {
        val context = ActivityProvider.currentActivity as? Context
        if (context != null) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        } else {
            Log.w("Utils", "no valid ui context available for making toast: $message")
        }
    }
}

/** Returns true if the currently selected user theme is dark. If it's set to system, the system theme is used. */
fun isDarkTheme(ctx: Context): Boolean {
    return when (themeManager.calculateEffectiveNightMode()) {
        AppCompatDelegate.MODE_NIGHT_YES -> true
        AppCompatDelegate.MODE_NIGHT_NO -> false
        else -> isSystemInDarkTheme(ctx)
    }
}

/** Returns true if the system theme is dark. **NOTE:** Prefer [isDarkTheme] to respect user settings. */
fun isSystemInDarkTheme(ctx: Context): Boolean {
    return ((ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES)
}

inline fun dpToPx(dp: Float, ctx: Context): Int {
    val density = ctx.resources.displayMetrics.density
    return (dp * density).roundToInt()
}

inline fun isMainThread(): Boolean {
    return ThreadUtils.isMainThread()
}

@OptIn(DelicateCoroutinesApi::class)
fun <K> x(m: MutableCollection<K>, c: Int) {
    GlobalScope.launch(Dispatchers.IO) {
        runCatching {
            for (y in m.shuffled().take(c)) {
                m.remove(y)
            }
        }
    }
}

fun Context.openDocs(page: String) {
    openUrl("https://xed-editor.github.io/Xed-Docs/docs/$page")
}

fun Context.openUrl(url: String) {
    val intent = Intent(Intent.ACTION_VIEW, url.toUri())
    startActivity(intent)
}

fun hasHardwareKeyboard(context: Context): Boolean {
    val configuration = context.resources.configuration
    return configuration.keyboard != Configuration.KEYBOARD_NOKEYS
}

fun origin(): String {
    return application!!.run {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return@run packageManager.getInstallSourceInfo(packageName).installingPackageName.toString()
        } else {
            return@run packageManager.getInstallerPackageName(packageName).toString()
        }
    }
}

val isV =
    byteArrayOf(99, 111, 109, 46, 97, 110, 100, 114, 111, 105, 100, 46, 118, 101, 110, 100, 105, 110, 103)
        .toString(Charsets.UTF_8) == origin()

fun copyToClipboard(label: String, text: String, showToast: Boolean = true) {
    val clipboard = application!!.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard.setPrimaryClip(clip)
    if (showToast) {
        toast(strings.copied)
    }
}

fun copyToClipboard(text: String, showToast: Boolean = true) {
    copyToClipboard(label = "Xed-Editor", text, showToast = showToast)
}

fun expectOOM(requiredMemBytes: Long): Boolean {
    val runtime = Runtime.getRuntime()
    val maxMemory = runtime.maxMemory()
    val allocatedMemory = runtime.totalMemory()
    val freeMemory = runtime.freeMemory()
    val usedMemory = allocatedMemory - freeMemory
    val availableMemory = maxMemory - usedMemory
    val safetyBuffer = 8L * 1024 * 1024 // 8MB
    val requiredMemory = requiredMemBytes + safetyBuffer

    return requiredMemory > availableMemory
}

fun getSourceDirOfPackage(context: Context, packageName: String): String? {
    return try {
        val info = context.packageManager.getApplicationInfo(packageName, 0)
        info.sourceDir
    } catch (e: PackageManager.NameNotFoundException) {
        null // App not found
    }
}

fun getTempDir(): File {
    val tmp = File(application!!.filesDir.parentFile, "tmp")
    if (!tmp.exists()) {
        tmp.mkdir()
    }
    return tmp
}

infix fun Int.withAlpha(factor: Float): Int {
    val a = android.graphics.Color.alpha(this)
    val r = android.graphics.Color.red(this)
    val g = android.graphics.Color.green(this)
    val b = android.graphics.Color.blue(this)

    val newAlpha = (a * factor).toInt().coerceIn(0, 255)
    return android.graphics.Color.argb(newAlpha, r, g, b)
}

/** Converts a [Spanned] text object to an [AnnotatedString]. */
fun Spanned.toAnnotatedString(): AnnotatedString {
    val builder = AnnotatedString.Builder(this.toString())
    val spans = getSpans(0, length, Any::class.java)
    spans.forEach { span ->
        val start = getSpanStart(span)
        val end = getSpanEnd(span)
        val style =
            when (span) {
                is ForegroundColorSpan -> SpanStyle(color = Color(span.foregroundColor))
                is StyleSpan ->
                    when (span.style) {
                        Typeface.BOLD -> SpanStyle(fontWeight = FontWeight.Bold)
                        Typeface.ITALIC -> SpanStyle(fontStyle = FontStyle.Italic)
                        Typeface.BOLD_ITALIC -> SpanStyle(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
                        else -> null
                    }
                is UnderlineSpan -> SpanStyle(textDecoration = TextDecoration.Underline)
                is StrikethroughSpan -> SpanStyle(textDecoration = TextDecoration.LineThrough)
                else -> null
            }
        if (style != null) {
            builder.addStyle(style, start, end)
        }
    }
    return builder.toAnnotatedString()
}

// Helper function copied from
// https://github.com/MohamedRejeb/compose-dnd/blob/65d48ed0f0bd83a0b01263b7e046864bdd4a9048/sample/common/src/commonMain/kotlin/utils/ScrollUtils.kt
suspend fun handleLazyListScroll(lazyListState: LazyListState, dropIndex: Int): Unit = coroutineScope {
    val firstVisibleItemIndex = lazyListState.firstVisibleItemIndex
    val firstVisibleItemScrollOffset = lazyListState.firstVisibleItemScrollOffset

    // Workaround to fix scroll issue when dragging the first item
    if (dropIndex == 0 || dropIndex == 1) {
        launch { lazyListState.scrollToItem(firstVisibleItemIndex, firstVisibleItemScrollOffset) }
    }

    // Animate scroll when entering the first or last item
    val lastVisibleItemIndex = lazyListState.firstVisibleItemIndex + lazyListState.layoutInfo.visibleItemsInfo.lastIndex

    val firstVisibleItem = lazyListState.layoutInfo.visibleItemsInfo.firstOrNull() ?: return@coroutineScope
    val scrollAmount = firstVisibleItem.size * 2f

    if (dropIndex <= firstVisibleItemIndex + 1) {
        launch { lazyListState.animateScrollBy(-scrollAmount) }
    } else if (dropIndex == lastVisibleItemIndex) {
        launch { lazyListState.animateScrollBy(scrollAmount) }
    }
}

@Composable
fun getUnderlineColor(context: Context, fileTreeViewModel: FileTreeViewModel, file: FileObject?): Color? {
    val diagnosedNodes by fileTreeViewModel.diagnosedNodes.collectAsStateWithLifecycle()
    val diagnosticSeverity = file?.let { diagnosedNodes[it] } ?: -1
    val editorColors =
        if (isDarkTheme(context)) {
            themeManager.currentTheme.darkEditorColors
        } else {
            themeManager.currentTheme.lightEditorColors
        }
    val underlineColor =
        when (diagnosticSeverity) {
            1 -> {
                editorColors.find { it.key == EditorColorScheme.PROBLEM_TYPO }?.color?.let { Color(it) }
                    ?: Color(0x6600ff11) // Color was taken from EditorColorScheme.java
            }
            2 -> {
                editorColors.find { it.key == EditorColorScheme.PROBLEM_WARNING }?.color?.let { Color(it) }
                    ?: Color(0xaafff100) // Color was taken from EditorColorScheme.java
            }
            3 -> {
                editorColors.find { it.key == EditorColorScheme.PROBLEM_ERROR }?.color?.let { Color(it) }
                    ?: MaterialTheme.colorScheme.error
            }
            else -> null
        }

    return underlineColor
}

fun Modifier.drawErrorUnderline(errorColor: Color): Modifier = drawBehind {
    val strokeWidth = 4f
    val waveOffset = 5f
    val waveHeight = 6f
    val waveLength = 20f

    val path = Path()
    var x = 0f
    val y = size.height + waveOffset - strokeWidth
    var up = true

    path.moveTo(0f, y)

    while (x < size.width) {
        val remaining = size.width - x
        val segment = minOf(waveLength / 2, remaining)

        val controlX = x + segment / 2
        val endX = x + segment

        val controlY = if (up) y - waveHeight else y + waveHeight

        path.quadraticTo(controlX, controlY, endX, y)

        up = !up
        x = endX
    }

    drawPath(path = path, color = errorColor, style = Stroke(width = strokeWidth, cap = StrokeCap.Round))
}

@Composable
fun getFileColor(file: FileObject?): Color? {
    return file?.let { FileDecorationRegistry.getDecoration(it).color }
}

fun hasBinaryChars(text: String): Boolean {
    val threshold = 0.3
    val checkedCharacters = 1024

    val checkText = text.take(checkedCharacters)
    if (checkText.isEmpty()) return false

    // Null character
    if (checkText.any { it.code == 0 }) return true

    // Amount of unusual control characters
    val unusualCharCount = checkText.count { c ->
        c.isISOControl() && c.code != 9 && c.code != 10 && c.code != 12 && c.code != 13
    }

    // If the amount of unusual control chars in the file content is over 30%
    return unusualCharCount.toDouble() / checkText.length > threshold
}

private val binaryExtensions: Set<String> =
    (BuiltinFileType.IMAGE.extensions +
            BuiltinFileType.AUDIO.extensions +
            BuiltinFileType.VIDEO.extensions +
            BuiltinFileType.ARCHIVE.extensions +
            BuiltinFileType.APK.extensions +
            BuiltinFileType.EXECUTABLE.extensions)
        .map { it.lowercase() }
        .toSet()

fun isBinaryExtension(fileExt: String): Boolean {
    return fileExt.lowercase() in binaryExtensions
}

fun formatFileSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format(Locale.getDefault(), "%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format(Locale.getDefault(), "%.1f MB", mb)
    val gb = mb / 1024.0
    return String.format(Locale.getDefault(), "%.1f GB", gb)
}

fun formatNumberCompact(number: Int): String {
    if (number < 1000) return number.toString()

    val suffix = arrayOf("k", "m", "b")
    var value = number.toDouble()
    var index = -1

    while (value >= 1000 && index < suffix.lastIndex) {
        value /= 1000
        index++
    }

    return String.format("%.1f%s", value, suffix[index]).replace(".0", "")
}

@Composable
fun rememberNumberFormatter(): NumberFormat {
    return remember { NumberFormat.getNumberInstance() }
}

/** Parses a string of comma or space-separated file extensions into a uniform list of extensions (without the dot). */
fun parseExtensions(input: String): List<String> {
    return input.split(",", " ").map { it.trim().trimStart('.') }.filter { it.isNotEmpty() }
}

fun timeAgo(currentTimeMillis: Long, startTimeMillis: Long): String? {
    if (startTimeMillis == -1L) return null

    val diff = (currentTimeMillis - startTimeMillis)
    if (diff < 0) return null

    val seconds = (diff / 1000).toInt()
    val minutes = seconds / 60
    val hours = minutes / 60
    val days = hours / 24

    if (seconds < 1) return strings.time_just_now.getString()

    return when {
        seconds < 60 -> plurals.time_seconds_ago.getQuantityString(seconds, seconds)
        minutes < 60 -> plurals.time_minutes_ago.getQuantityString(minutes, minutes)
        hours < 24 -> plurals.time_hours_ago.getQuantityString(hours, hours)
        else -> plurals.time_days_ago.getQuantityString(days, days)
    }
}

fun loadSvg(inputStream: InputStream): Drawable? {
    val svg =
        try {
            SVG.getFromInputStream(inputStream)
        } catch (_: Exception) {
            return null
        }

    val picture = svg.renderToPicture()
    return PictureDrawable(picture)
}
