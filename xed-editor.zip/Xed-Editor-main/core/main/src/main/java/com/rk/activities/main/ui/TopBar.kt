package com.rk.activities.main.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material3.DrawerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import com.rk.activities.main.MainViewModel
import com.rk.components.GlobalToolbarActions
import com.rk.components.isPermanentDrawer
import com.rk.drawer.DrawerViewModel
import com.rk.resources.strings
import com.rk.utils.isV
import com.rk.utils.toast
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun XedTopBar(
    drawerState: DrawerState,
    viewModel: MainViewModel,
    drawerViewModel: DrawerViewModel,
    fullScreen: Boolean,
    onDrag: (Float) -> Unit = {},
    onDragEnd: () -> Unit = {},
) {
    val scope = rememberCoroutineScope()
    val showTopBar by viewModel.showTopBar.collectAsStateWithLifecycle()

    AnimatedVisibility(visible = showTopBar, enter = expandVertically(), exit = shrinkVertically()) {
        TopAppBar(
            windowInsets = if (fullScreen) WindowInsets() else TopAppBarDefaults.windowInsets,
            modifier =
                Modifier.pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onVerticalDrag = { _, dragAmount -> onDrag(dragAmount) },
                        onDragEnd = { onDragEnd() },
                        onDragCancel = { onDragEnd() },
                    )
                },
            title = {},
            navigationIcon = {
                if (!isPermanentDrawer) {
                    IconButton(
                        onClick = {
                            scope.launch { if (drawerState.isClosed) drawerState.open() else drawerState.close() }
                        }
                    ) {
                        Icon(Icons.Outlined.Menu, null)
                    }
                }
            },
            actions = {
                GlobalToolbarActions(viewModel, drawerViewModel)

                if (viewModel.tabs.isNotEmpty()) {
                    val tab =
                        if (isV) {
                            viewModel.tabs[viewModel.currentTabIndex]
                        } else {
                            viewModel.tabs.getOrNull(viewModel.currentTabIndex)
                        }

                    if (tab != null) {
                        tab.apply { Actions() }
                    } else {
                        toast(strings.unknown_error)
                    }
                }
            },
        )
    }
}
