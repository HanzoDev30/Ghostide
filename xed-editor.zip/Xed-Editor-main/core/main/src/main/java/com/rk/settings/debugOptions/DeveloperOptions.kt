@file:Suppress("ktlint:standard:filename")

package com.rk.settings.debugOptions

import androidx.activity.compose.LocalActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavController
import com.rk.activities.settings.SettingsRoutes
import com.rk.components.RoundedValueSlider
import com.rk.components.SettingsItem
import com.rk.components.compose.preferences.base.PreferenceGroup
import com.rk.components.compose.preferences.base.PreferenceLayout
import com.rk.resources.getString
import com.rk.resources.strings
import com.rk.settings.Settings
import com.rk.utils.application
import com.rk.utils.dialogRes
import com.rk.utils.logError
import com.rk.utils.toast
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.time.Duration.Companion.milliseconds

private var flipperJob: Job? = null

@Suppress("ktlint:standard:function-naming")
@OptIn(DelicateCoroutinesApi::class)
@Composable
fun DeveloperOptions(modifier: Modifier = Modifier, navController: NavController) {
    val activity = LocalActivity.current

    val memoryUsage = remember { mutableStateOf("Unknown") }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            while (isActive) {
                delay(300.milliseconds)
                val runtime = Runtime.getRuntime()
                val usedMem = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
                memoryUsage.value = "$usedMem/${runtime.maxMemory() / (1024 * 1024)}MB"
            }
        }
    }

    PreferenceLayout(label = stringResource(strings.debug_options)) {
        PreferenceGroup(heading = stringResource(strings.general)) {
            SettingsItem(
                label = stringResource(strings.force_crash),
                description = stringResource(strings.force_crash_desc),
                showSwitch = false,
                default = false,
                sideEffect = {
                    dialogRes(
                        activity = activity,
                        title = strings.force_crash.getString(),
                        msg = strings.force_crash_confirm.getString(),
                        onCancel = {},
                        onOk = { Thread { throw HarmlessException("Force crash") }.start() },
                    )
                },
            )

            SettingsItem(
                label = stringResource(strings.memory_usage),
                description = memoryUsage.value,
                showSwitch = false,
                default = false,
            )

            SettingsItem(
                label = stringResource(strings.strict_mode),
                description = stringResource(strings.strict_mode_desc),
                showSwitch = true,
                default = Settings.strict_mode,
                sideEffect = { Settings.strict_mode = it },
            )

            SettingsItem(
                label = stringResource(strings.anr_watchdog),
                description = stringResource(strings.anr_watchdog_desc),
                default = Settings.anr_watchdog,
                sideEffect = { Settings.anr_watchdog = it },
            )

            SettingsItem(
                label = stringResource(strings.desktop_mode),
                description = stringResource(strings.desktop_mode_desc),
                showSwitch = true,
                default = Settings.desktop_mode,
                sideEffect = { Settings.desktop_mode = it },
            )

            SettingsItem(
                label = stringResource(strings.theme_flipper),
                description = stringResource(strings.theme_flipper_desc),
                showSwitch = true,
                default = Settings.theme_flipper,
                sideEffect = {
                    Settings.theme_flipper = it
                    if (it) {
                        startThemeFlipperIfNotRunning()
                    }
                },
            )

            SettingsItem(
                label = stringResource(strings.reset_consent),
                description = stringResource(strings.reset_consent_desc),
                showSwitch = false,
                default = false,
                sideEffect = {
                    Settings.shown_disclaimer = false
                    toast(strings.restart_required)
                },
            )
        }

        PreferenceGroup(heading = stringResource(strings.logs)) {
            SettingsItem(
                label = stringResource(strings.verbose_errors),
                description = stringResource(strings.verbose_errors_desc),
                showSwitch = true,
                default = Settings.verbose_error,
                sideEffect = { Settings.verbose_error = it },
            )

            SettingsItem(
                label = stringResource(strings.record_rpc_traffic),
                description = stringResource(strings.record_rpc_traffic_desc),
                showSwitch = true,
                default = Settings.record_rpc,
                sideEffect = { Settings.record_rpc = it },
            )

            RoundedValueSlider(
                label = stringResource(strings.lsp_log_limit),
                description = stringResource(strings.log_limit_desc),
                min = 1_000,
                max = 100_000,
                stepSize = 5_000,
                default = Settings.lsp_log_limit,
                onValueChanged = { Settings.lsp_log_limit = it },
            )

            RoundedValueSlider(
                label = stringResource(strings.app_log_limit),
                description = stringResource(strings.log_limit_desc),
                min = 1_000,
                max = 100_000,
                stepSize = 5_000,
                default = Settings.app_log_limit,
                onValueChanged = { Settings.app_log_limit = it },
            )

            SettingsItem(
                label = stringResource(strings.enable_logcat),
                description = stringResource(strings.enable_logcat_desc),
                showSwitch = true,
                default = Settings.enable_logcat,
                sideEffect = {
                    Settings.enable_logcat = it
                    if (it) {
                        LogcatService.start(application!!)
                    } else {
                        LogcatService.stop(application!!)
                    }
                },
            )

            SettingsItem(
                label = stringResource(strings.view_logs),
                description = stringResource(strings.view_app_logs),
                default = false,
                showSwitch = false,
                onClick = { navController.navigate(SettingsRoutes.AppLogs.route) },
            )
        }
    }
}

fun startThemeFlipperIfNotRunning() {
    if (flipperJob == null || flipperJob?.isActive?.not() == true) {
        flipperJob =
            GlobalScope.launch(Dispatchers.IO) {
                runCatching {
                    while (isActive && Settings.theme_flipper) {
                        delay(7000.milliseconds)

                        val mode =
                            if (Settings.theme_mode == AppCompatDelegate.MODE_NIGHT_NO) {
                                AppCompatDelegate.MODE_NIGHT_YES
                            } else {
                                AppCompatDelegate.MODE_NIGHT_NO
                            }

                        Settings.theme_mode = mode

                        withContext(Dispatchers.Main) { AppCompatDelegate.setDefaultNightMode(mode) }
                    }
                }
                    .onFailure { logError(it) }
            }
    }
}

class HarmlessException(msg: String) : Exception(msg)
