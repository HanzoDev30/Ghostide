package com.rk.activities.settings

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.rk.animations.NavigationAnimationTransitions
import com.rk.lsp.LspRegistry
import com.rk.settings.SettingsRegistry
import com.rk.settings.SettingsScreen
import com.rk.settings.about.AboutScreen
import com.rk.settings.app.SettingsAppScreen
import com.rk.settings.debugOptions.AppLogs
import com.rk.settings.debugOptions.DeveloperOptions
import com.rk.settings.editor.AppFontScreen
import com.rk.settings.editor.DefaultEncoding
import com.rk.settings.editor.DefaultLineEnding
import com.rk.settings.editor.EditExtraKeys
import com.rk.settings.editor.EditToolbarActions
import com.rk.settings.editor.EditorFontScreen
import com.rk.settings.editor.ExcludeFiles
import com.rk.settings.editor.FormatterSettings
import com.rk.settings.editor.SettingsEditorScreen
import com.rk.settings.keybinds.KeybindingsScreen
import com.rk.settings.language.LanguageScreen
import com.rk.settings.lsp.LspInitializationOptions
import com.rk.settings.lsp.LspServerDetail
import com.rk.settings.lsp.LspServerLogs
import com.rk.settings.lsp.LspSettings
import com.rk.settings.support.Support
import com.rk.settings.theme.ThemeScreen

@Composable
fun SettingsNavHost(navController: NavHostController, activity: SettingsActivity) {
    NavHost(
        navController = navController,
        startDestination = SettingsRoutes.Settings.route,
        enterTransition = { NavigationAnimationTransitions.enterTransition },
        exitTransition = { NavigationAnimationTransitions.exitTransition },
        popEnterTransition = { NavigationAnimationTransitions.popEnterTransition },
        popExitTransition = { NavigationAnimationTransitions.popExitTransition },
    ) {
        composable(SettingsRoutes.Settings.route) { SettingsScreen(navController) }
        composable(SettingsRoutes.AppSettings.route) { SettingsAppScreen(activity, navController) }
        composable(SettingsRoutes.EditorSettings.route) { SettingsEditorScreen(navController) }
        composable(SettingsRoutes.Keybindings.route) { KeybindingsScreen() }

        composable(SettingsRoutes.About.route) { AboutScreen() }
        composable(SettingsRoutes.EditorFontScreen.route) { EditorFontScreen() }
        composable(SettingsRoutes.AppFontScreen.route) { AppFontScreen() }

        composable(SettingsRoutes.DefaultEncoding.route) { DefaultEncoding() }
        composable(SettingsRoutes.DefaultLineEnding.route) { DefaultLineEnding() }
        composable(SettingsRoutes.ToolbarActions.route) { EditToolbarActions() }
        composable(SettingsRoutes.ExtraKeys.route) { EditExtraKeys() }
        composable(
            "${SettingsRoutes.ExcludeFiles.route}/{isDrawer}",
            arguments = listOf(navArgument("isDrawer", builder = { type = NavType.BoolType })),
        ) {
            val isDrawer = it.arguments?.getBoolean("isDrawer")!!
            ExcludeFiles(isDrawer)
        }
        composable(SettingsRoutes.DeveloperOptions.route) { DeveloperOptions(navController = navController) }
        composable(SettingsRoutes.AppLogs.route) { AppLogs() }
        composable(SettingsRoutes.Support.route) { Support() }
        composable(SettingsRoutes.LanguageScreen.route) { LanguageScreen() }
        composable(SettingsRoutes.Formatters.route) { FormatterSettings(navController) }
        composable(SettingsRoutes.LspSettings.route) { LspSettings(navController) }
        composable(
            "${SettingsRoutes.LspServerDetail.route}/{serverId}",
            arguments = listOf(navArgument("serverId", builder = { type = NavType.StringType })),
        ) { backStackEntry ->
            val serverId = backStackEntry.arguments?.getString("serverId")!!
            val server = LspRegistry.getForId(serverId)!!
            LspServerDetail(navController, server)
        }
        composable(
            "${SettingsRoutes.LspInitializationOptions.route}/{serverId}",
            arguments = listOf(navArgument("serverId", builder = { type = NavType.StringType })),
        ) { backStackEntry ->
            val serverId = backStackEntry.arguments?.getString("serverId")!!
            val server = LspRegistry.getForId(serverId)!!
            LspInitializationOptions(server)
        }
        composable(
            "${SettingsRoutes.LspServerLogs.route}/{serverId}/{instanceId}",
            arguments =
                listOf(
                    navArgument("serverId", builder = { type = NavType.StringType }),
                    navArgument("instanceId", builder = { type = NavType.StringType }),
                ),
        ) { backStackEntry ->
            val serverId = backStackEntry.arguments?.getString("serverId")!!
            val server = LspRegistry.getForId(serverId)!!
            val instanceId = backStackEntry.arguments?.getString("instanceId")!!
            LspServerLogs(server, instanceId)
        }
        composable(SettingsRoutes.Themes.route) { ThemeScreen(navController) }

        SettingsRegistry.routes.value.forEach { customRoute ->
            composable(customRoute.route, arguments = customRoute.arguments) { backStackEntry ->
                customRoute.content(navController, backStackEntry)
            }
        }
    }
}
