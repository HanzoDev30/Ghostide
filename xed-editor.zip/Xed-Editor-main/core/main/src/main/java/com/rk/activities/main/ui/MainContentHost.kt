package com.rk.activities.main.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScaffoldDefaults
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.rememberNestedScrollInteropConnection
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rk.activities.main.MainActivity
import com.rk.components.DialogRegistry
import com.rk.components.ResponsiveDrawer
import com.rk.drawer.DrawerContent
import com.rk.drawer.DrawerPersistence
import com.rk.filetree.FileTreeViewModel
import com.rk.resources.getString
import com.rk.resources.strings
import com.rk.search.SearchViewModel
import com.rk.settings.Settings
import com.rk.tabs.editor.EditorTab
import com.rk.theme.XedTheme
import com.rk.utils.dialogRes
import kotlinx.coroutines.launch
import java.lang.ref.WeakReference

var fileTreeViewModel = WeakReference<FileTreeViewModel?>(null)
var searchViewModel = WeakReference<SearchViewModel?>(null)

var snackbarHostStateRef: WeakReference<SnackbarHostState?> = WeakReference(null)
var drawerStateRef: WeakReference<DrawerState?> = WeakReference(null)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainActivity.MainContentHost(
    fileTreeViewModel: FileTreeViewModel = viewModel(),
    searchViewModel: SearchViewModel = viewModel(),
) {
    com.rk.activities.main.ui.fileTreeViewModel = WeakReference(fileTreeViewModel)
    com.rk.activities.main.ui.searchViewModel = WeakReference(searchViewModel)

    XedTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
            val snackbarHostState = remember { SnackbarHostState() }

            LaunchedEffect(drawerState) { drawerStateRef = WeakReference(drawerState) }
            LaunchedEffect(snackbarHostState) { snackbarHostStateRef = WeakReference(snackbarHostState) }

            LaunchedEffect(drawerState.isOpen) {
                val viewModel = MainActivity.instance?.viewModel ?: return@LaunchedEffect
                if (drawerState.isOpen) {
                    viewModel.tabManager.currentTab?.let {
                        if (it is EditorTab) {
                            it.editorState.editor.get()?.clearFocus()
                        }
                    }
                } else if (drawerState.isClosed) {
                    viewModel.tabManager.currentTab?.let {
                        if (it is EditorTab) {
                            it.editorState.editor.get()?.apply {
                                requestFocus()
                                requestFocusFromTouch()
                            }
                        }
                    }
                }
            }

            LaunchedEffect(Settings.fullscreen) {
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                val statusBarType = WindowInsetsCompat.Type.statusBars()
                if (Settings.fullscreen) {
                    controller.hide(statusBarType)
                } else {
                    controller.show(statusBarType)
                }
            }

            val keyboardShown = WindowInsets.isImeVisible
            LaunchedEffect(keyboardShown, Settings.smart_toolbar) {
                viewModel.setShowTopBar(!Settings.smart_toolbar || !keyboardShown)
            }

            val scope = rememberCoroutineScope()

            BackHandler {
                if (drawerState.isOpen) {
                    scope.launch { drawerState.close() }
                } else if (viewModel.tabs.isNotEmpty() && Settings.confirm_exit) {
                    dialogRes(
                        title = strings.attention.getString(),
                        msg = strings.confirm_exit.getString(),
                        onCancel = {},
                        onOk = { finish() },
                        okRes = strings.exit,
                    )
                } else {
                    finish()
                }
            }

            val density = LocalDensity.current
            var accumulator = 0f
            val softThreshold = with(density) { 50.dp.toPx() }
            val hardThreshold = with(density) { 100.dp.toPx() }

            val extraKeysPadding = if (Settings.split_extra_keys) 88.dp else 48.dp
            val taskOutputPadding = if (TaskOutputState.isActive) 72.dp else 0.dp
            val snackbarBottomPadding = (if (Settings.show_extra_keys) extraKeysPadding else 0.dp) + taskOutputPadding

            val mainContent: @Composable () -> Unit = {
                Scaffold(
                    contentWindowInsets =
                        if (Settings.fullscreen) WindowInsets() else ScaffoldDefaults.contentWindowInsets,
                    snackbarHost = {
                        SnackbarHost(
                            hostState = snackbarHostState,
                            modifier = Modifier.padding(bottom = snackbarBottomPadding),
                        ) { data ->
                            Snackbar(
                                snackbarData = data,
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                actionColor = MaterialTheme.colorScheme.primary,
                                dismissActionContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    },
                    modifier = Modifier.nestedScroll(rememberNestedScrollInteropConnection()),
                    topBar = {
                        XedTopBar(
                            drawerState = drawerState,
                            viewModel = viewModel,
                            drawerViewModel = drawerViewModel,
                            fullScreen = Settings.fullscreen,
                            onDrag = { dragAmount ->
                                accumulator += dragAmount

                                viewModel.setDraggingPalette(true)

                                scope.launch {
                                    val newProgress = (accumulator / hardThreshold).coerceIn(0f, 1f)
                                    viewModel.draggingPaletteProgress.snapTo(newProgress)
                                }
                            },
                            onDragEnd = {
                                val shouldOpen = accumulator >= softThreshold
                                if (shouldOpen) {
                                    Settings.command_palette_swipe_used = true
                                }
                                scope.launch {
                                    viewModel.setDraggingPalette(shouldOpen)
                                    viewModel.draggingPaletteProgress.animateTo(
                                        if (shouldOpen) 1f else 0f,
                                        animationSpec = spring(stiffness = 800f),
                                    )
                                }
                                accumulator = 0f
                            },
                        )
                    },
                ) { innerPadding ->
                    MainContent(
                        innerPadding = innerPadding,
                        mainViewModel = viewModel,
                        drawerViewModel = drawerViewModel,
                        fileTreeViewModel = fileTreeViewModel,
                        drawerState = drawerState,
                    )
                }
            }

            val sheetContent: @Composable ColumnScope.() -> Unit = {
                LaunchedEffect(Unit) {
                    drawerViewModel.setLoading(true)
                    DrawerPersistence.restoreState(drawerViewModel)
                    drawerViewModel.setLoading(false)
                }
                DrawerContent(Settings.fullscreen)
            }

            ResponsiveDrawer(
                drawerState = drawerState,
                fullscreen = Settings.fullscreen,
                mainContent = mainContent,
                sheetContent = sheetContent,
            )

            DialogRegistry.getDialogs().forEach { dialog ->
                dialog()
            }
        }
    }
}
