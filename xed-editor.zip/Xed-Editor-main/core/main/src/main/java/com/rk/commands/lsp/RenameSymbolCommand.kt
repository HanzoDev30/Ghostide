package com.rk.commands.lsp

import com.rk.DefaultScope
import com.rk.commands.LspActionContext
import com.rk.commands.LspCommand
import com.rk.commands.LspNonActionContext
import com.rk.icons.Icon
import com.rk.lsp.renameSymbol
import com.rk.resources.drawables
import com.rk.resources.getString
import com.rk.resources.strings

class RenameSymbolCommand : LspCommand() {
    override val id: String = "lsp.rename_symbol"

    override fun getLabel(): String = strings.rename_symbol.getString()

    override fun execute(context: LspActionContext) {
        renameSymbol(DefaultScope, context.editorTab)
    }

    override fun isSupported(context: LspNonActionContext): Boolean {
        return context.lspConnector.isRenameSymbolSupported()
    }

    override fun getIcon(): Icon = Icon.ResourceIcon(drawables.manage_search)
}
