package com.rk.commands.global

import android.view.KeyEvent
import com.rk.commands.ActionContext
import com.rk.commands.GlobalCommand
import com.rk.commands.KeyCombination
import com.rk.components.GlobalDialogs
import com.rk.icons.Icon
import com.rk.resources.drawables
import com.rk.resources.getString
import com.rk.resources.strings

class NewFileCommand : GlobalCommand() {
    override val id: String = "global.new_file"

    override fun getLabel(): String = strings.new_file.getString()

    override fun execute(context: ActionContext) {
        GlobalDialogs.addDialog.value = true
    }

    override fun getIcon(): Icon = Icon.ResourceIcon(drawables.add)

    override val defaultKeybinds: KeyCombination = KeyCombination(keyCode = KeyEvent.KEYCODE_N, ctrl = true)
}
