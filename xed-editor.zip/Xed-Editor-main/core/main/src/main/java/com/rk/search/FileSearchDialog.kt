package com.rk.search

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.input.TextFieldLineLimits
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rk.activities.main.MainViewModel
import com.rk.components.XedDialog
import com.rk.components.compose.utils.addIf
import com.rk.file.FileObject
import com.rk.file.toFileWrapper
import com.rk.filetree.FileIcon
import com.rk.filetree.getAppropriateName
import com.rk.resources.fillPlaceholders
import com.rk.resources.strings
import com.rk.tabs.editor.EditorTab
import com.rk.utils.getFileColor
import com.rk.utils.rememberNumberFormatter
import java.io.File

@Composable
fun FileSearchDialog(
    mainViewModel: MainViewModel,
    searchViewModel: SearchViewModel,
    projectFile: FileObject,
    onFinish: () -> Unit,
    onSelect: (FileObject, FileObject) -> Unit,
) {
    val focusRequester = remember { FocusRequester() }
    val context = LocalContext.current

    val fileSearchQuery by searchViewModel.fileSearchQuery.collectAsStateWithLifecycle()
    val isSearchingFiles by searchViewModel.isSearchingFiles.collectAsStateWithLifecycle()
    val fileSearchResults by searchViewModel.fileSearchResults.collectAsStateWithLifecycle()
    val isIndexingMap by searchViewModel.isIndexing.collectAsStateWithLifecycle()
    val isIndexingProject = isIndexingMap[projectFile] == true

    val editorTab = mainViewModel.currentTab as? EditorTab
    val textFieldState =
        rememberTextFieldState(
            editorTab?.editorState?.editor?.get()?.getSelectedText() ?: fileSearchQuery
        )

    LaunchedEffect(textFieldState.text) { searchViewModel.setFileSearchQuery(textFieldState.text.toString()) }

    LaunchedEffect(isIndexingProject, fileSearchQuery) {
        searchViewModel.launchFileSearch(context, projectFile)
    }

    val viewportHeight = with(LocalDensity.current) { LocalWindowInfo.current.containerSize.height.toDp() }
    XedDialog(onDismissRequest = onFinish, modifier = Modifier.imePadding()) {
        Column(modifier = Modifier.animateContentSize().height(viewportHeight * 0.8f)) {
            TextField(
                state = textFieldState,
                lineLimits = TextFieldLineLimits.SingleLine,
                keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Search),
                modifier = Modifier.fillMaxWidth().focusRequester(focusRequester),
                placeholder = { Text(text = stringResource(strings.enter_name)) },
                supportingText = {
                    Text(
                        text = stringResource(strings.searching_in).fillPlaceholders(projectFile.getAppropriateName()),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(top = 16.dp, start = 16.dp, bottom = 0.dp, end = 16.dp),
            ) {
                if (isIndexingProject || isSearchingFiles) {
                    CircularProgressIndicator(modifier = Modifier.size(9.dp), strokeWidth = 2.dp)
                }
                val numberFormatter = rememberNumberFormatter()
                val resultCount by remember {
                    derivedStateOf { numberFormatter.format(fileSearchResults.size) }
                }
                Text(
                    stringResource(
                            when {
                                isIndexingProject -> strings.indexing
                                fileSearchResults.isNotEmpty() -> strings.results
                                else -> strings.no_results
                            }
                        )
                        .fillPlaceholders(resultCount)
                )
            }

            LaunchedEffect(Unit) { focusRequester.requestFocus() }

            LazyColumn(modifier = Modifier.padding(vertical = 8.dp)) {
                items(items = fileSearchResults, key = { it }) { codeLine ->
                    Box(modifier = Modifier.animateItem()) {
                        SearchItem(File(codeLine.path).toFileWrapper(), projectFile, onFinish, onSelect)
                    }
                }
            }
        }
    }
}

@Composable
fun SearchItem(
    fileObject: FileObject,
    projectFile: FileObject,
    onDismissRequest: () -> Unit,
    onSelect: (FileObject, FileObject) -> Unit,
) {
    val isHidden = fileObject.getName().startsWith(".") || fileObject.getAbsolutePath().contains("/.")
    val fileNameColor = getFileColor(fileObject) ?: Color.Unspecified

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier =
            Modifier.fillMaxWidth()
                .clickable(
                    enabled = true,
                    onClick = {
                        onDismissRequest()
                        onSelect(projectFile, fileObject)
                    },
                )
                .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Box(modifier = Modifier.addIf(isHidden) { alpha(0.5f) }) { FileIcon(file = fileObject) }

        Column(modifier = Modifier.padding(start = 8.dp)) {
            Text(
                text = fileObject.getAppropriateName(),
                color = fileNameColor,
                style = MaterialTheme.typography.bodyLarge,
            )
            Text(
                text = "." + fileObject.getAbsolutePath().removePrefix(projectFile.getAbsolutePath()),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            )
        }
    }
}
