package com.rk.editor

import android.graphics.Color
import com.rk.App.Companion.themeManager
import com.rk.utils.withAlpha
import io.github.rosemoe.sora.langs.textmate.TextMateColorScheme
import io.github.rosemoe.sora.langs.textmate.registry.ThemeRegistry
import io.github.rosemoe.sora.langs.textmate.registry.model.ThemeModel
import io.github.rosemoe.sora.widget.schemes.EditorColorScheme

class XedColorScheme(
    private val patchArgs: Editor.PatchArgs?,
    themeModel: ThemeModel,
    themeRegistry: ThemeRegistry = ThemeRegistry.getInstance(),
) : TextMateColorScheme(themeRegistry, themeModel) {

    init {
        themeRegistry.loadTheme(themeModel)
    }

    override fun applyDefault() {
        super.applyDefault()
        applyPatches()
    }

    private fun applyPatches() {
        if (patchArgs == null) return
        applyPatchesTo(this, patchArgs)
    }

    companion object {
        fun applyPatchesTo(colorScheme: EditorColorScheme, patchArgs: Editor.PatchArgs) {
            val (
                isDarkMode,
                editorSurface,
                surfaceContainer,
                highSurfaceContainer,
                highestSurfaceContainer,
                onSurface,
                colorPrimary,
                selectionBg,
                handleColor,
                gutterColor,
                currentLine,
                dividerColor,
                errorColor,
            ) = patchArgs

            fun setColors(color: Int, vararg types: Int) {
                types.forEach { colorScheme.setColor(it, color) }
            }

            setColors(Color.TRANSPARENT, HIGHLIGHTED_DELIMITERS_UNDERLINE)

            setColors(editorSurface, WHOLE_BACKGROUND)

            setColors(
                surfaceContainer,
                TEXT_ACTION_WINDOW_BACKGROUND,
                COMPLETION_WND_BACKGROUND,
                DIAGNOSTIC_TOOLTIP_BACKGROUND,
                SIGNATURE_BACKGROUND,
                HOVER_BACKGROUND,
                LINE_NUMBER_PANEL,
                TEXT_INLAY_HINT_BACKGROUND,
            )

            setColors(surfaceContainer withAlpha 0.4f, MINIMAP_BACKGROUND)
            setColors(highSurfaceContainer withAlpha 0.6f, MINIMAP_VIEWPORT, MINIMAP_VIEWPORT_BORDER)

            setColors(highSurfaceContainer, COMPLETION_WND_ITEM_CURRENT, TEXT_HIGHLIGHT_BACKGROUND)

            setColors(highestSurfaceContainer, SNIPPET_BACKGROUND_EDITING, TEXT_HIGHLIGHT_STRONG_BACKGROUND)
            setColors(highestSurfaceContainer withAlpha 0.8f, SNIPPET_BACKGROUND_RELATED)
            setColors(highestSurfaceContainer withAlpha 0.6f, SNIPPET_BACKGROUND_INACTIVE)

            setColors(
                onSurface,
                TEXT_ACTION_WINDOW_ICON_COLOR,
                COMPLETION_WND_TEXT_PRIMARY,
                COMPLETION_WND_TEXT_SECONDARY,
                DIAGNOSTIC_TOOLTIP_BRIEF_MSG,
                DIAGNOSTIC_TOOLTIP_DETAILED_MSG,
                SIGNATURE_TEXT_NORMAL,
                HOVER_TEXT_NORMAL,
                LINE_NUMBER,
                LINE_NUMBER_CURRENT,
                LINE_NUMBER_PANEL_TEXT,
                TEXT_INLAY_HINT_FOREGROUND,
            )

            setColors(handleColor, SELECTION_HANDLE)
            setColors(selectionBg, SELECTION_INSERT, MATCHED_TEXT_BACKGROUND, SELECTED_TEXT_BACKGROUND)
            setColors(
                colorPrimary,
                HIGHLIGHTED_DELIMITERS_FOREGROUND,
                HIGHLIGHTED_DELIMITERS_BORDER,
                SIGNATURE_TEXT_HIGHLIGHTED_PARAMETER,
                HOVER_TEXT_HIGHLIGHTED,
                DIAGNOSTIC_TOOLTIP_ACTION,
                COMPLETION_WND_TEXT_MATCHED,
            )

            setColors(onSurface withAlpha 0.6f, BLOCK_LINE_CURRENT)
            setColors(onSurface withAlpha 0.4f, NON_PRINTABLE_CHAR, BLOCK_LINE)
            setColors(onSurface withAlpha 0.3f, SCROLL_BAR_THUMB)
            setColors(onSurface withAlpha 0.2f, SCROLL_BAR_THUMB_PRESSED)

            setColors(currentLine, CURRENT_LINE)
            setColors(gutterColor, LINE_NUMBER_BACKGROUND)
            setColors(
                dividerColor,
                LINE_DIVIDER,
                STICKY_SCROLL_DIVIDER,
                COMPLETION_WND_CORNER,
                SIGNATURE_BORDER,
                HOVER_BORDER,
            )

            setColors(errorColor, PROBLEM_ERROR)

            patchArgs.apply {
                setColors(gitAdded withAlpha 0.3f, GIT_MARKER_ADDED)
                setColors(gitModified withAlpha 0.3f, GIT_MARKER_MODIFIED)
                setColors(gitDeleted withAlpha 0.3f, GIT_MARKER_DELETED)
                setColors(gitConflicted withAlpha 0.3f, GIT_MARKER_CONFLICTED)
            }

            val editorColors =
                if (isDarkMode) {
                    themeManager.currentTheme.darkEditorColors
                } else {
                    themeManager.currentTheme.lightEditorColors
                }

            if (editorColors.isNotEmpty()) {
                editorColors.forEach { colorScheme.setColor(it.key, it.color) }
            }
        }

        const val GIT_MARKER_ADDED = END_COLOR_ID + 1
        const val GIT_MARKER_MODIFIED = END_COLOR_ID + 2
        const val GIT_MARKER_DELETED = END_COLOR_ID + 3
        const val GIT_MARKER_CONFLICTED = END_COLOR_ID + 4
    }
}
