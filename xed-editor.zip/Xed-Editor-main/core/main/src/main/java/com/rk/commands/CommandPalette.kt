package com.rk.commands

import androidx.activity.compose.BackHandler
import androidx.activity.compose.LocalActivity
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rk.animations.NavigationAnimationTransitions
import com.rk.components.XedDialog
import com.rk.components.compose.utils.addIf
import com.rk.icons.XedIcon
import com.rk.resources.strings
import com.rk.settings.Settings
import com.rk.theme.Typography
import kotlinx.coroutines.DelicateCoroutinesApi

@OptIn(DelicateCoroutinesApi::class)
@Composable
fun CommandPalette(
    progress: Float,
    commands: List<Command>,
    lastUsedCommand: Command?,
    initialChildCommands: List<Command>? = null,
    initialPlaceholder: String? = null,
    onDismissRequest: () -> Unit,
) {
    var searchQuery by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    var childCommands by remember { mutableStateOf(initialChildCommands) }
    var placeholderOverride by remember { mutableStateOf(initialPlaceholder) }

    val sortedCommands by
        remember(commands, lastUsedCommand) {
            derivedStateOf {
                buildList {
                    lastUsedCommand?.let { add(it) }
                    addAll(commands.filter { it != lastUsedCommand }.sortedBy { it.getLabel() })
                }
            }
        }

    val visibleCommands = childCommands ?: sortedCommands

    val filteredCommands by
        remember(visibleCommands, searchQuery) {
            derivedStateOf {
                visibleCommands
                    .filter {
                        it.getLabel().contains(searchQuery, ignoreCase = true) ||
                            it.prefix?.contains(searchQuery, ignoreCase = true) == true
                    }
                    .filter {
                        it.isSupported()
                    }
            }
        }

    val groupedCommands = filteredCommands.groupBy { it.sectionId }

    val offsetY = with(LocalDensity.current) { (1f - progress) * 100.dp.toPx() }

    XedDialog(
        onDismissRequest = onDismissRequest,
        modifier =
            Modifier.graphicsLayer {
                    this.alpha = progress
                    this.translationY = -offsetY
                }
                .imePadding(),
    ) {
        BackHandler(enabled = childCommands != null && initialChildCommands == null) {
            childCommands = null
            placeholderOverride = null
            searchQuery = ""
        }

        Column(modifier = Modifier.animateContentSize()) {
            TextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                maxLines = 1,
                keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Search),
                modifier = Modifier.fillMaxWidth().focusRequester(focusRequester),
                placeholder = {
                    Text(
                        if (childCommands != null && placeholderOverride != null) {
                            placeholderOverride!!
                        } else {
                            stringResource(strings.type_command)
                        }
                    )
                },
            )

            if (
                Settings.command_palette_open_count >= 3 &&
                    !Settings.command_palette_swipe_used &&
                    !Settings.command_palette_note_dismissed
            ) {
                Row(
                    modifier =
                        Modifier.fillMaxWidth()
                            .background(MaterialTheme.colorScheme.secondaryContainer)
                            .padding(vertical = 8.dp, horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = stringResource(strings.command_palette_swipe_hint),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.weight(1f),
                    )

                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = stringResource(strings.close),
                        modifier =
                            Modifier.size(16.dp).clickable {
                                Settings.command_palette_note_dismissed = true
                            },
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                }
            }

            LaunchedEffect(progress) { if (progress == 1f) focusRequester.requestFocus() }

            AnimatedContent(
                targetState = childCommands != null,
                transitionSpec = {
                    if (targetState) {
                        NavigationAnimationTransitions.enterTransition togetherWith
                            NavigationAnimationTransitions.exitTransition
                    } else {
                        NavigationAnimationTransitions.popEnterTransition togetherWith
                            NavigationAnimationTransitions.popExitTransition
                    }
                },
            ) { isSubpage ->
                LazyColumn(modifier = Modifier.padding(vertical = 8.dp)) {
                    groupedCommands.forEach { (index, commands) ->
                        items(items = commands, key = { it.id }) { command ->
                            Box(modifier = Modifier.animateItem()) {
                                val isRecentlyUsed = command == lastUsedCommand
                                CommandItem(
                                    command,
                                    isRecentlyUsed,
                                    searchQuery,
                                    onDismissRequest,
                                    onNavigateToChildren = { placeholder, commands ->
                                        childCommands = commands
                                        placeholderOverride = placeholder
                                        searchQuery = ""
                                    },
                                    isSubpage = isSubpage,
                                )
                            }
                        }

                        if (index != groupedCommands.keys.last()) {
                            item { HorizontalDivider() }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CommandItem(
    command: Command,
    recentlyUsed: Boolean,
    searchQuery: String,
    onDismissRequest: () -> Unit,
    onNavigateToChildren: (String?, List<Command>) -> Unit,
    isSubpage: Boolean,
) {
    val activity = LocalActivity.current
    val enabled by remember { derivedStateOf { command.isEnabled() } }
    val childCommands = command.childCommands
    val keyCombination = KeybindingsManager.getKeyCombinationForCommand(command)

    val startIndex = command.getLabel().indexOf(searchQuery, ignoreCase = true)
    val endIndex = startIndex + searchQuery.length
    val highlightColor = MaterialTheme.colorScheme.primary
    val highlightedString =
        remember(searchQuery) {
            buildAnnotatedString {
                append(command.getLabel())

                if (startIndex != -1) {
                    addStyle(
                        style = SpanStyle(color = highlightColor, fontWeight = FontWeight.Bold),
                        start = startIndex,
                        end = endIndex,
                    )
                }
            }
        }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier =
            Modifier.fillMaxWidth()
                .clickable(
                    enabled = enabled,
                    onClick = {
                        Settings.last_used_command = command.id
                        if (childCommands.isNotEmpty()) {
                            onNavigateToChildren(command.getChildSearchPlaceholder(), childCommands)
                        } else {
                            onDismissRequest()
                            command.execute(ActionContext(activity!!))
                        }
                    },
                )
                .addIf(!enabled) { alpha(0.38f) }
                .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        XedIcon(
            icon = command.getIcon(),
            modifier = Modifier.size(16.dp),
            contentDescription = command.getLabel(),
            tint =
                if (command is ToggleableCommand && command.isOn()) {
                    MaterialTheme.colorScheme.primary
                } else LocalContentColor.current,
        )

        Column(modifier = Modifier.fillMaxWidth().weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                command.prefix?.let { Text(text = "$it: ", color = MaterialTheme.colorScheme.primary) }
                Text(
                    text = highlightedString,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodyLarge,
                    color =
                        if (command is ToggleableCommand && command.isOn()) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            Color.Unspecified
                        },
                )
                if (recentlyUsed) {
                    Text(
                        text = stringResource(strings.recently_used),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        modifier = Modifier.padding(start = 8.dp),
                    )
                }
            }

            if (!isSubpage) {
                CommandProvider.getParentCommand(command)?.getLabel()?.let {
                    Text(
                        text = it,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    )
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            keyCombination?.let {
                Text(
                    text = keyCombination.getDisplayName(),
                    fontFamily = FontFamily.Monospace,
                    style = Typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            if (childCommands.isNotEmpty()) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                    contentDescription = null,
                    modifier = Modifier.height(16.dp),
                )
            }
        }
    }
}
